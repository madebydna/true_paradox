//
//  glossy_buttonsAppDelegate.h
//  glossy-buttons
//
//  Created by Oscar Del Ben on 5/24/10.
//  Copyright DibiStore 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@class glossy_buttonsViewController;

@interface glossy_buttonsAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    glossy_buttonsViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet glossy_buttonsViewController *viewController;

@end

