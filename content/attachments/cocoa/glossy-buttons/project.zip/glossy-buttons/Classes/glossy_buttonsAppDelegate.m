//
//  glossy_buttonsAppDelegate.m
//  glossy-buttons
//
//  Created by Oscar Del Ben on 5/24/10.
//  Copyright DibiStore 2010. All rights reserved.
//

#import "glossy_buttonsAppDelegate.h"
#import "glossy_buttonsViewController.h"

@implementation glossy_buttonsAppDelegate

@synthesize window;
@synthesize viewController;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    
    // Override point for customization after app launch    
    [window addSubview:viewController.view];
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [viewController release];
    [window release];
    [super dealloc];
}


@end
