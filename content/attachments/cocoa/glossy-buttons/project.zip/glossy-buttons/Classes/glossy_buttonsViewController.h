//
//  glossy_buttonsViewController.h
//  glossy-buttons
//
//  Created by Oscar Del Ben on 5/24/10.
//  Copyright DibiStore 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface glossy_buttonsViewController : UIViewController {

}

@end

